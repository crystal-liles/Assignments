﻿using System;
using CustomerManagement;
using Microsoft.VisualStudio.TestTools.UnitTesting;

/*
 * Crystal Liles
 */

namespace CustomerManagementTests
{
    class ProductTest
    {
        public void FullNameTestValid()
        {
            //-- Arrange

            //--Act

            //-- Assert

        }
        public void FullNameFirstNameEmpty()
        {
            //-- Arrange

            //--Act

            //-- Assert

        }
        public void FullNameLastNameEmpty()
        {
            //-- Arrange

            //--Act

            //-- Assert

        }
    }
}
