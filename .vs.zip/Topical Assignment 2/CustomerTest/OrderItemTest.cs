﻿using System;
using CustomerManagement;
using Microsoft.VisualStudio.TestTools.UnitTesting;

/*
 * Crystal Liles
 */

namespace CustomerManagementTests
{
    class OrderItemTest
    {
        public void OrderItemValidateValid()
        {
            //-- Arrange
            
            //--Act
            
            //-- Assert
            
        }
        public void OrderItemValidateMissingQuantity()
        {
            //-- Arrange

            //--Act

            //-- Assert

        }
        public void OrderItemValidateMissingProductID()
        {
            //-- Arrange

            //--Act

            //-- Assert

        }
        public void OrderItemValidateMissingPurchasePrice()
        {
            //-- Arrange

            //--Act

            //-- Assert

        }
    }
}
